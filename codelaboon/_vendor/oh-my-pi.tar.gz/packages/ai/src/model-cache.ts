/**
 * SQLite-backed model cache for atomic cross-process access.
 * Replaces per-provider JSON files with a single cache.db.
 */
import { Database } from "bun:sqlite";
import { getModelDbPath } from "@oh-my-pi/pi-utils";
import type { Api, Model } from "./types";

const CACHE_SCHEMA_VERSION = 2;

interface CacheRow {
	provider_id: string;
	version: number;
	updated_at: number;
	authoritative: number;
	models: string;
}

interface CacheEntry<TApi extends Api = Api> {
	models: Model<TApi>[];
	fresh: boolean;
	authoritative: boolean;
	updatedAt: number;
}

let sharedDb: Database | null = null;
let sharedDbPath: string | null = null;

function getDb(dbPath?: string): Database {
	const resolvedPath = dbPath ?? getModelDbPath();
	if (sharedDb && sharedDbPath === resolvedPath) {
		return sharedDb;
	}
	if (sharedDb) {
		sharedDb.close();
	}
	const db = new Database(resolvedPath, { create: true });
	db.run("PRAGMA journal_mode = WAL");
	db.run("PRAGMA busy_timeout = 3000");
	db.run(`
		CREATE TABLE IF NOT EXISTS model_cache (
			provider_id TEXT PRIMARY KEY,
			version INTEGER NOT NULL,
			updated_at INTEGER NOT NULL,
			authoritative INTEGER NOT NULL DEFAULT 0,
			models TEXT NOT NULL
		)
	`);
	sharedDb = db;
	sharedDbPath = resolvedPath;
	return db;
}

export function readModelCache<TApi extends Api>(
	providerId: string,
	ttlMs: number,
	now: () => number,
	dbPath?: string,
): CacheEntry<TApi> | null {
	try {
		const db = getDb(dbPath);
		const row = db.query<CacheRow, [string]>("SELECT * FROM model_cache WHERE provider_id = ?").get(providerId);
		if (!row || row.version !== CACHE_SCHEMA_VERSION) {
			return null;
		}
		const models = JSON.parse(row.models) as Model<TApi>[];
		const ageMs = now() - row.updated_at;
		const fresh = Number.isFinite(ageMs) && ageMs >= 0 && ageMs <= ttlMs;
		return {
			models,
			fresh,
			authoritative: row.authoritative === 1,
			updatedAt: row.updated_at,
		};
	} catch {
		return null;
	}
}

export function writeModelCache<TApi extends Api>(
	providerId: string,
	updatedAt: number,
	models: Model<TApi>[],
	authoritative: boolean,
	dbPath?: string,
): void {
	try {
		const db = getDb(dbPath);
		db.run(
			`INSERT OR REPLACE INTO model_cache (provider_id, version, updated_at, authoritative, models)
			 VALUES (?, ?, ?, ?, ?)`,
			[providerId, CACHE_SCHEMA_VERSION, updatedAt, authoritative ? 1 : 0, JSON.stringify(models)],
		);
	} catch {
		// Cache writes are best-effort; failures should not break model resolution.
	}
}
