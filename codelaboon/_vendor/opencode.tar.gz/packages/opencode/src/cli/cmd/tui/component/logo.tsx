import { TextAttributes } from "@opentui/core"
import { createSignal, onMount, onCleanup } from "solid-js"
import { useTheme } from "@tui/context/theme"

export function Logo() {
  const { theme } = useTheme()
  const [frame, setFrame] = createSignal(false)
  onMount(() => {
    if (process.env.NO_COLOR || process.env.CODELABOON_NO_ANIMATION) return
    const timer = setInterval(() => setFrame((value) => !value), 700)
    onCleanup(() => clearInterval(timer))
  })
  return (
    <box alignItems="center" gap={1}>
      <text fg={theme.primary} selectable={false}>
        {frame() ? "       o       \n    __|__      \n __/ o   \\___/|\n \\__________/ " : "       .       \n    __|__      \n __/ o   \\___/|\n \\__________/ "}
      </text>
      <text fg={theme.text} attributes={TextAttributes.BOLD}>c o d e l a b o o n</text>
      <text fg={theme.textMuted}>code · delegate · verify</text>
    </box>
  )
}
